//	VC-MP windows server 0.3x.
//-----------------------------------------------------------------------

This server is beta software and is not recommended
to be run on large public game servers. Do so at your
own risk.

Note: There must be a config file at vcmp/config.ini,
Server looks for vcmp/config.ini to load.

If you wish to run a VC-MP server, 
copy/rename the vcmp/config.vcmp.ini to vcmp/config.ini
then run vcmp-svr.exe

If you wish to run an LC-MP server, 
copy/rename the vcmp/config.lcmp.ini to vcmp/config.ini
then run vcmp-svr.exe

Note: config file must have an admin password set, be
sure to edit your config.ini with a text editor to set one

Admin commands.

> First identify with the /admin (password) command.
> Press F5 ingame to show the scoreboard.
> Identify a player id you wish to kick, ban or both.
> To kick a player use /kick (playerid)
> Use /getip (playerid) to print a player's IP address.
> Use /ban IP.mask to prevent an IP from reconnecting.
> Ban IP.masks can use wildcards e.g. 24.105.0.* to be a class C network.