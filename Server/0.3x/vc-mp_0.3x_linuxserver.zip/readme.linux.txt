//	VC-MP linux server 0.3x.
//-----------------------------------------------------------------------

This server is beta software and is not recommended
to be run on large public game servers. Do so at your
own risk.

File List:
> vcmp03x (linux binary)
> announce (linux binary)
> config.vcmp.ini, config.lcmp.ini (server configurations, please edit first)
> this readme

> Upload vcmp03x and announce to your host as BINARY
> Change the permissions on vcmp03x and announce to execute
> Configure the ini
> Run '$ ./vcmp03x config.filename.ini' to start the server.
	example:
		Run '$ ./vcmp03x config.vcmp.ini' to start the VC-MP server.
			-OR-
		Run '$ ./vcmp03x config.lcmp.ini' to start the LC-MP server.
> Please don't run as root.

Note: config file must have an admin password set, be
sure to edit your config.ini with a text editor to set one

Admin commands.

> First identify with the /admin (password) command.
> Press F5 ingame to show the scoreboard.
> Identify a player id you wish to kick, ban or both.
> To kick a player use /kick (playerid)
> Use /getip (playerid) to print a player's IP address.
> Use /ban IP.mask to prevent an IP from reconnecting.
> Ban IP.masks can use wildcards e.g. 24.105.0.* to be a class C network.


