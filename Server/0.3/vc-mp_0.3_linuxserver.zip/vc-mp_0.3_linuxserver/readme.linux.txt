VC-MP linux server 0.3. Installation Instructions.

This server is beta software and is not recommended
to be run on large public game servers. Do so at your
own risk.

> Upload vcmp-svr.bin to your host as BINARY.
> Change the permissions on vcmp-svr.bin to execute.
> Upload one of the vc-mp server configuration inis
> Run './vcmp03.bin config.ini' to start the VC-MP server.

Ingame admin commands.

> First identify with the /admin (password) command.
> Press F5 ingame to show the scoreboard.
> Identify a player id you wish to kick, ban or both.
> To kick a player use /kick (playerid)
> Use /getip (playerid) to print a player's IP address.
> Use /ban IP.mask to prevent an IP from reconnecting.
> Ban IP.masks can use wildcards e.g. 24.105.0.* to be a class C network.