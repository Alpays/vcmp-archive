// Create a table holding the commands
commands <- [ "info", "health", "armour", "heal" ];

// Create a table holding names that cannot be used in game
bannedNames <- [ "Admin", "Administrator" ];

function onPlayerJoin( player )
{
	// Check if the name is banned
	foreach ( name in bannedNames )
	{
		if ( name == player.Name )
		{
			MessagePlayer( "!! Error: Invalid name !!", player );
			KickPlayer( player );
			return;
		}
	}
	
	print( "Player " + player.Name + " joined. [" + player.ID + "]" );
}

function onScriptLoad( )
{
	print( "Script \"Main.nut\" started successfully" );
}

function onScriptUnload( )
{
	print( "Script \"Main.nut\" has been unloaded." );
}

function onPlayerChat( player, text )
{
	local backupText = text;
	local firstChar = backupText.slice( 0, 1 );
	if (  firstChar == "!" )
	{
		// The following function makes any ! commands go to the OnPlayerCommand handler
		local splittext = text.slice( 1 );
		local params = split( splittext, " " );
		if ( params.len() == 1 ) onPlayerCommand( player, params[ 0 ], "" );
		else 
		{
			splittext = splittext.slice( splittext.find( " " ) + 1 );
			onPlayerCommand( player, params[ 0 ], splittext );
		}		
	}
}

function onPlayerCommand( player, cmd, text )
{
	if ( cmd == "info" )
	{
		Message( "Default VCMP Script - Version 1.0" );
		Message( "Created By: VRocker" );
	}
	else if ( cmd == "commands" )
	{
		local cmdThing = 0;
		local cmdOutput = null;
		if ( commands.len() >= 1 ) 
		{
			MessagePlayer( "--- Commands ---", player );
			for ( local id = 0; id < commands.len(); id += 1 )
			{
				if ( cmdThing < 10 )
				{
					if ( cmdOutput ) cmdOutput = cmdOutput + ", " + commands[ id ];
					else cmdOutput = commands[ id ];
				
					cmdThing += 1;
				}
				else
				{
					MessagePlayer( cmdOutput, player );
				
					cmdOutput = "";
					cmtThing = 0;
				}
			}
			
			if ( cmdOutput != "" ) MessagePlayer( cmdOutput, player );
		}
		else MessagePlayer( "No commands are currently available", player );			
	}
	
	else if ( cmd == "health" )
	{
		if ( text )
		{
			local a = split( text, " " );
			
			local plr = null;
			if ( !IsNum( a[0] ) ) plr = FindPlayer( a[0] );
			else plr = FindPlayer( a[0].tointeger() );
			
			if ( plr ) Message( plr.Name + "'s Health: " + plr.Health + "%" );
			else MessagePlayer( "Error: Invalid Player", player );
		}
		else Message( player.Name + "'s Health: " + player.Health + "%" );
	}
	else if ( cmd == "armour" )
	{
		if ( text )
		{
			local a = split( text, " " );
			
			local plr = null;
			if ( !IsNum( a[0] ) ) plr = FindPlayer( a[0] );
			else plr = FindPlayer( a[0].tointeger() );
			
			if ( plr ) Message( plr.Name + "'s Armour: " + plr.Armour + "%" );
			else MessagePlayer( "Error: Invalid Player", player );
		}
		else Message( player.Name + "'s Armour: " + player.Armour + "%" );
	}
	
	else if ( cmd == "heal" )
	{
		local health = player.Health;
		if ( health < 100 )
		{
			// calculate the cost based on their health
			local cost = ( ( 250 / 100 ) * ( 100 - health ) );
			if ( player.Cash >= cost )
			{
				player.Cash -= cost;
				player.Health = 100;
				MessagePlayer( "You have been healed (Cost: $" + cost + ")", player );
			}
			else MessagePlayer( "Sorry, you cannot afford to be healed (Cost: $" + cost + ")", player );
		}
		else MessagePlayer( "You already have full health", player );
	}
}

function onConsoleInput( cmd, text )
{
	if ( cmd == "players" )
	{
		// Lists a table of players currently in game
		local maxPlayers = GetMaxPlayers();
		local i = 0, ii = 0, iii = 0;
		local buffer = null;
		while ( ( i < maxPlayers ) && ( ii < GetPlayers() ) )
		{
			local plr = FindPlayer( i );
			if ( plr )
			{
				if ( !buffer ) 
				{
					buffer = plr.Name;
					iii++;
				}
				else if ( ++iii < 3 ) buffer = buffer + "     |     " + plr.Name;
				else
				{
					print( buffer );
					buffer = plr.Name;
					
					iii = 0;
				}
				
				ii++;
			}
			
			i++;
		}
		if ( buffer ) print( buffer );
		
		print( "Total players: " + GetPlayers() );
	}
}