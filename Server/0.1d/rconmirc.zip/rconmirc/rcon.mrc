;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; VC:MP 0.1b mIRC Rcon Script
;   - By Mike
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Output parsing
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
alias rcon.output {

  if ($1 == [join]) {
    .signal vcmp.join $2-
  }
  elseif ($1 == [chat]) {
    .signal vcmp.chat $left($2,-1) $3-
  }
  elseif ($1 == [part]) {
    .signal vcmp.part $2-
  }
  elseif ($1 == [death]) {
    .signal vcmp.death $vcmp.getdeathinfo($2).name $vcmp.getdeathinfo($2).id
  }
  elseif ($1 == [kill]) {
    .signal vcmp.kill $vcmp.getdeathinfo($2).name $vcmp.getdeathinfo($2).id $vcmp.getdeathinfo($4).name $vcmp.getdeathinfo($4).id
  }
  elseif ($str($chr(42),3) Remote console connected* iswm $1-) {
    .signal vcmp.connected 1
  }
}

alias vcmp.getdeathinfo {
  if ($prop == id) {
    if ($+(*,$chr(40),255,$chr(41)) iswm $1) {
      !return 255
    }
    else {
      !return $right($left($1,-1),1)
    }
  }
  elseif ($prop == name) {
    if ($+(*,$chr(40),255,$chr(41)) iswm $1) {
      !return $left($1,-5)
    }
    else {
      !return $left($1,-3)
    }
  }
  else !return -1
}

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Rcon commands
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
alias vcmp.command {
  dll %vcmp.path RconCommand $1-
}
alias vcmp.connect {
  dll %vcmp.path RconConnect $1-
}
alias vcmp.disconnect {
  dll %vcmp.path RconDisconnect
}
alias vcmp.status {
  !return $dll(%vcmp.path,RconIsConnected,)
}
