VC:MP 0.1b Rcon for mIRC
Example echo script

Installation:

 > Extract the 'rconmircdll.dll', 'rcon.mrc' and 'rconexample.mrc' files anywhere, but preferably into the mIRC folder.
 > Edit DLL path and echo channel in the 'rconexample.mrc' file with notepad or mIRC's built-in script editor.
 > Load the 'rcon.mrc' and 'rconexample.mrc' files.
 > Type '/vcmp <Server address> <port> <password>' without the '<' and '>'s to connect.


These scripts are just examples and you don't have to use them to make use of the dll.
The following DLL commands can be used:

 /dll Path\to\rconmircdll.dll RconConnect <OutputCommand> <Address> <Port> <password>
 /dll Path\to\rconmircdll.dll RconDisconnect
 /dll Path\to\rconmircdll.dll RconCommand <commands>
 $dll(Path\to\rconmircdll.dll,RconIsConnected,)        ; Returns 1 or 0 if the Rcon is connected or disconnected respectively.

OutputCommand: This is the command that the DLL will exectute to return output. E.G: /echo
Commands: These are any commands you can use in the rcon. E.G: kick 2 (See the help file included with VC:MP for more info)

* Note: If you want to create your own scripts, it is preferable that you use the same signal syntax as used in 'rcon.mrc' for compatibility.