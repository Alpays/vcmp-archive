;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; VC:MP 0.1b mIRC Rcon Example script
;   - By Mike
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; EDIT THE PATH AND ECHO CHANNEL!
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

alias vcmp {

  ; Path to DLL
  set %vcmp.path DLL\rconmircdll.dll

  ; Echo channel
  set %vcmp.echo #mallecho

  if (!$3) {
    echo -a Missing parameters. Syntax: /vcmp <Address> <Port> <Password>
    halt
  }

  dll %vcmp.path RconConnect /rcon.output $1 $2 $3

}

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Echo script
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

on *:SIGNAL:vcmp.connected:{
  if (%vcmp.echo) {
    msg %vcmp.echo *** Remote console connected.
  }
}

; Joins
; $1 = PlayerID
; $2 = Player Name
on *:SIGNAL:vcmp.join:{
  if (%vcmp.echo) {
    msg %vcmp.echo 3*** $+($chr(91),$1,$chr(93)) $2 joined the game.
  }
}

; Chat
; $1  = Player Name
; $2- = Chat
on *:SIGNAL:vcmp.chat:{
  if (%vcmp.echo) {
    msg %vcmp.echo @ < $+ $1 $+ > $2-
  }
}

; Parts
; $1 = PlayerID
; $2 = Player Name
; $3 = Reason (0 = timeout/1 = quit/2 = kicked)
on *:SIGNAL:vcmp.part:{
  if (%vcmp.echo) {
    if ($3 == 0) { var %reason = Timeout }
    elseif ($3 == 2) { var %reason = Kicked }

    msg %vcmp.echo 3*** $+($chr(91),$1,$chr(93)) $2 left the game. $iif(%reason,$+($chr(40),%reason,$chr(41)), $+ )
  }
}

; Deaths
; $1 = Player Name
; $2 = TeamID (255 = deathmatch)
on *:SIGNAL:vcmp.death:{
  if (%vcmp.echo) {
    msg %vcmp.echo 4* $1 died.
  }
}

; Kills
; $1 = Killer Player Name
; $2 = Killer TeamID (255 = deathmatch)
; $3 = Killed Player Name
; $4 = Killed TeamID (255 = deathmatch)
on *:SIGNAL:vcmp.kill:{
  if (%vcmp.echo) {
    msg %vcmp.echo 4* $1 killed $3 $+ .
  }
}


;
